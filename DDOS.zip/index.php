<?php
// Define your Telegram bot token here
$bot_token = '7429570306:AAFgHFKfzs6KHGlNBFmHsLKTD82DzLDSHlI';

// Admin user IDs
$admin_id = ["7015873681"];

// File to store allowed user IDs
define('USER_FILE', 'users.txt');

// File to store command logs
define('LOG_FILE', 'log.txt');

// Read allowed user IDs from file
function read_users() {
    if (file_exists(USER_FILE)) {
        return file(USER_FILE, FILE_IGNORE_NEW_LINES);
    } else {
        return [];
    }
}

$allowed_user_ids = read_users();

// Add user to the file of allowed users
function add_user_to_file($user_id) {
    file_put_contents(USER_FILE, $user_id . "\n", FILE_APPEND);
}

// Log command execution
function log_command($user_id, $target, $port, $time) {
    $username = getUsername($user_id);
    $log_entry = "Username: $username\nTarget: $target\nPort: $port\nTime: $time\n\n";
    file_put_contents(LOG_FILE, $log_entry, FILE_APPEND);
}

// Get username from user ID
function getUsername($user_id) {
    $result = file_get_contents("https://api.telegram.org/bot$bot_token/getChat?chat_id=$user_id");
    $json = json_decode($result, true);
    if (isset($json['result']['username'])) {
        return "@" . $json['result']['username'];
    } else {
        return "UserID: $user_id";
    }
}

// Record command logs
function record_command_logs($user_id, $command, $target = null, $port = null, $time = null) {
    $log_entry = "UserID: $user_id | Time: " . date("Y-m-d H:i:s") . " | Command: $command";
    if ($target) {
        $log_entry .= " | Target: $target";
    }
    if ($port) {
        $log_entry .= " | Port: $port";
    }
    if ($time) {
        $log_entry .= " | Time: $time";
    }
    file_put_contents(LOG_FILE, $log_entry . "\n", FILE_APPEND);
}

// Function to add a user ID to the list of allowed users
function add_user($user_id) {
    global $admin_id, $allowed_user_ids;
    if (in_array($user_id, $admin_id)) {
        if (!in_array($user_id, $allowed_user_ids)) {
            add_user_to_file($user_id);
            $allowed_user_ids[] = $user_id;
            $response = "User $user_id Added Successfully.";
        } else {
            $response = "User already exists.";
        }
    } else {
        $response = "Only Admin Can Run This Command.";
    }
    return $response;
}

// Function to remove a user ID from the list of allowed users
function remove_user($user_id) {
    global $admin_id, $allowed_user_ids;
    if (in_array($user_id, $admin_id)) {
        if (in_array($user_id, $allowed_user_ids)) {
            $index = array_search($user_id, $allowed_user_ids);
            unset($allowed_user_ids[$index]);
            $user_ids_string = implode("\n", $allowed_user_ids);
            file_put_contents(USER_FILE, $user_ids_string);
            $response = "User $user_id removed successfully.";
        } else {
            $response = "User $user_id not found in the list.";
        }
    } else {
        $response = "Only Admin Can Run This Command.";
    }
    return $response;
}

// Function to clear the command logs
function clear_logs() {
    global $admin_id;
    if (in_array($user_id, $admin_id)) {
        if (file_exists(LOG_FILE)) {
            file_put_contents(LOG_FILE, '');
            $response = "Logs Cleared Successfully";
        } else {
            $response = "Logs are already cleared. No data found.";
        }
    } else {
        $response = "Only Admin Can Run This Command.";
    }
    return $response;
}

// Function to show all authorized users
function show_all_users() {
    global $admin_id;
    if (in_array($user_id, $admin_id)) {
        if (file_exists(USER_FILE)) {
            $user_ids = file(USER_FILE, FILE_IGNORE_NEW_LINES);
            if (!empty($user_ids)) {
                $response = "Authorized Users:\n";
                foreach ($user_ids as $user_id) {
                    $username = getUsername($user_id);
                    $response .= "- $username (ID: $user_id)\n";
                }
            } else {
                $response = "No data found";
            }
        } else {
            $response = "No data found";
        }
    } else {
        $response = "Only Admin Can Run This Command.";
    }
    return $response;
}

// Function to show recent command logs
function show_recent_logs() {
    global $admin_id;
    if (in_array($user_id, $admin_id)) {
        if (file_exists(LOG_FILE) && filesize(LOG_FILE) > 0) {
            $logs = file_get_contents(LOG_FILE);
            return $logs;
        } else {
            return "No data found.";
        }
    } else {
        return "Only Admin Can Run This Command.";
    }
}

// Function to handle the "/ss" command for BGMI/PUBG Lite attacks
function start_attack($message, $target, $port, $time) {
    global $allowed_user_ids, $ss_cooldown;
    $user_id = $message["from"]["id"];
    if (in_array($user_id, $allowed_user_ids)) {
        if (!isset($ss_cooldown[$user_id]) || (time() - $ss_cooldown[$user_id]) > 300) {
            $ss_cooldown[$user_id] = time();
            record_command_logs($user_id, '/ss', $target, $port, $time);
            log_command($user_id, $target, $port, $time);
            $response = "{$message['from']['username']}, 𝐀𝐓𝐓𝐀𝐂𝐊 𝐒𝐓𝐀𝐑𝐓𝐄𝐃.\n\n𝐓𝐚𝐫𝐠𝐞𝐭: $target\n𝐏𝐨𝐫𝐭: $port\n𝐓𝐢𝐦𝐞: $time 𝐒𝐞𝐜𝐨𝐧𝐝𝐬\n𝐌𝐞𝐭𝐡𝐨𝐝: BGMI / PUBG LITE\nBy Hacker Rajput 🕸 Website : Sharpshooterlite.com\n\nKeep Support 💪 Otherwise Off This Bot Free Service ✅🚩\nGo To Website sharpshooterlite.com Join Channel Please 😘";
            // Add your attack logic here
        } else {
            $response = "You Are On Cooldown. Please Wait 5min Before Running The /ss Command Again.";
        }
    } else {
        $response = "You Are Not Authorized To Use This Command.\nBy Hacker Rajput 🕸 Website : Sharpshooterlite.com\n\nKeep Support 💪 Otherwise Off This Bot Free Service ✅🚩\nGo To Website sharpshooterlite.com Join Channel Please 😘";
    }
    sendMessage($user_id, $response);
}

function show_command_logs($message) {
    global $allowed_user_ids;
    $user_id = $message["from"]["id"];
    if (in_array($user_id, $allowed_user_ids)) {
        if (file_exists(LOG_FILE)) {
            $command_logs = file(LOG_FILE, FILE_IGNORE_NEW_LINES);
            $user_logs = array_filter($command_logs, function($log) use ($user_id) {
                return strpos($log, "UserID: $user_id") !== false;
            });
            if (!empty($user_logs)) {
                $response = "Your Command Logs:\n" . implode("\n", $user_logs);
            } else {
                $response = "No Command Logs Found For You.";
            }
        } else {
            $response = "No command logs found.";
        }
    } else {
        $response = "You Are Not Authorized To Use This Command.";
    }
    sendMessage($user_id, $response);
}

function show_help($message) {
    global $allowed_user_ids;
    $user_id = $message["from"]["id"];
    $help_text = "Available commands:\n";
    $help_text .= "/ss : Method For Bgmi / Pubg Lite Servers.\n";
    $help_text .= "/rules : Please Check Before Use !!.\n";
    $help_text .= "/mylogs : To Check Your Recents Attacks.\n";
    $help_text .= "/plan : Checkout Our Botnet Rates.\n\n";
    if (in_array($user_id, $allowed_user_ids)) {
        $help_text .= "Admin Commands:\n";
        $help_text .= "/admincmd : Shows All Admin Commands.\n";
    }
    $response = "$help_text\nBy Hacker Rajput 🕸 Website : Sharpshooterlite.com\n\nKeep Support 💪 Otherwise Off This Bot Free Service ✅🚩\nGo To Website sharpshooterlite.com Join Channel Please 😘";
    sendMessage($user_id, $response);
}

?>